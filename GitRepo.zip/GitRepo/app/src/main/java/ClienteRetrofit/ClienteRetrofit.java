package ClienteRetrofit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ClienteRetrofit {

    private static final String BASE_URL = "https://api.github.com";
    private static final String username = "Dbalsec";
    private static Retrofit retrofit = null;

    /**
     * Obtener una instancia de la clase Retrofit, que se utiliza para construir y realizar solicitudes HTTP a una API web específica.
     * @return Devuelve la instancia de Retrofit
     */
    public static Retrofit obtenerCliente() {
        if (retrofit == null) {

            retrofit = new Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();
        }
        return retrofit;
    }

    /**
     *
     * @return devuelve el nombre de usuario que se utilizará como parte de las solicitudes a la API de GitHub.
     */
    public static String obtenerNombreUsuarioCliente() {

        return username;
    }

}