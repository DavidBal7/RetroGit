package ClienteRetrofit;

import com.example.gitrepo.RepoForm;

import java.util.List;

import modelos.Repo;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface APIGit {

    @GET("users/{username}/repos")
    Call<List<Repo>> obtenerRepositorios(
            @Path("username") String username
    );

    @DELETE("/repos/{repoOwner}/{repoName}")
    Call<Void> eliminarRepositorio(
            @Header("Authorization") String authorization,
            @Path("repoOwner") String username,
            @Path("repoName") String repoName
    );

    @POST("/user/repos")
    Call<Void> crearRepositorio(
            @Header("Authorization") String authorization,
            @Body RepoForm.RepositoryRequestBody repositoryRequestBody
    );

    @PATCH("/repos/{repoOwner}/{repoName}")
    Call<Void> editarRepositorio(
            @Header("Authorization") String authorization,
            @Path("repoOwner") String username,
            @Path("repoName") String repoName,
            @Body RepoForm.RepositoryRequestBody repositoryRequestBody
    );

    public static String obtenerNombreUsuarioCliente() {
        return ClienteRetrofit.obtenerNombreUsuarioCliente();
    }

    public static APIGit obtenerAPIGit() {
        Retrofit retrofit = ClienteRetrofit.obtenerCliente();
        return retrofit.create(APIGit.class);
    }
}
