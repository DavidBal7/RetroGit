package com.example.gitrepo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;
import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import modelos.Repo;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import ClienteRetrofit.APIGit;
public class RepoForm extends AppCompatActivity {
    private EditText etName, etDescription;
    private Button btnSave;
    private APIGit githubApi = APIGit.obtenerAPIGit();
    private boolean editMode = false;
    private String repositoryNameToUpdate;

    /**
     *
     * @param savedInstanceState
     *
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.repoform);

        etName = findViewById(R.id.etName);
        etDescription = findViewById(R.id.etDescription);

        btnSave = findViewById(R.id.btnSave);
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.getBoolean("modo edicion", false)) {
            editMode = true;
            repositoryNameToUpdate = extras.getString("Nombre_Repositorio", "");
            etName.setText(repositoryNameToUpdate);
            etDescription.setText(extras.getString("Descripcion_Repositorio", ""));
            btnSave.setText("Actualizar");
        }

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editMode) {
                    updateRepository();
                } else {
                    saveRepository();
                }
            }
        });
    }

    public class RepositoryRequestBody {

        private String name;
        private String description;

        /**
         * @param name
         * @param description
         */
        public RepositoryRequestBody(String name, String description) {
            this.name = name;
            this.description = description;
        }
    }

    private void saveRepository() {
        String name = etName.getText().toString();
        String description = etDescription.getText().toString();

        if (name.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "El Nombre y la Descripción son parametros obligatorios", Toast.LENGTH_SHORT).show();
        } else {

            String authorization = "Bearer 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";
            RepositoryRequestBody requestBody = new RepositoryRequestBody(name, description);

            Call<Void> call = githubApi.crearRepositorio(authorization,requestBody);
            Log.d(TAG, "Creando Repositorio - Creador: " + authorization + ", Nombre: " + name + ", Descripcion " + description);

            call.enqueue(new Callback<Void>() {
                /**
                 * @param call
                 * @param response
                 */
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    if (response.isSuccessful()) {
                        Toast.makeText(RepoForm.this, "Repositorio creado", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(RepoForm.this, "Error al crear el repositorio", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "Error al crear el repositorio.");
                    }
                }
                /**
                 * @param call
                 * @param t
                 */
                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    Toast.makeText(RepoForm.this, "Error de conexión al crear el repositorio", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }


    private void updateRepository() {
        String newName = etName.getText().toString();
        String newDescription = etDescription.getText().toString();

        if (newName.isEmpty() || newDescription.isEmpty()) {
            Toast.makeText(this, "El Nombre y la Descripción son parametros obligatorios", Toast.LENGTH_SHORT).show();
        } else {
            String authorization = "Bearer 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";
            String username = " Dbalsec";
            RepositoryRequestBody requestBody = new RepositoryRequestBody(newName, newDescription);

            Call<Void> call = githubApi.editarRepositorio(authorization,username,repositoryNameToUpdate,requestBody);
            Log.d(TAG, "Editando Repositorio - Token: " + authorization + ", usuario: " + username + ", Nombre del repositorio: " + repositoryNameToUpdate + ", Cuerpo " + requestBody);

            call.enqueue(new Callback<Void>() {
                /**
                 * @param call
                 * @param response
                 */
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    if (response.isSuccessful()) {
                        Toast.makeText(RepoForm.this, "Repositorio actualizado exitosamente", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(RepoForm.this, "Error al actualizar el repositorio", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "Error al actualizar el repositorio.");
                    }
                }
                /**
                 * @param call
                 * @param t
                 */
                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    Toast.makeText(RepoForm.this, "Error de conexión al actualizar el repositorio", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

}