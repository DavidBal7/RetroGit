package com.example.gitrepo;


import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

import adaptadores.RepoAdapter;
import modelos.Repo;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import ClienteRetrofit.APIGit;
import ClienteRetrofit.ClienteRetrofit;

public class MainActivity extends AppCompatActivity implements RepoAdapter.OnDeleteClickListener, RepoAdapter.OnEditClickListener {

    private RecyclerView recyclerView;
    private RepoAdapter repositoryAdapter;
    private List<Repo> repositories;
    private APIGit githubApi = APIGit.obtenerAPIGit();

    /**
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        Button btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openRepositoryForm();
            }
        });

        this.loadRepositories();
    }


    @Override
    protected void onResume() {
        super.onResume();
        this.loadRepositories();
    }

    private void loadRepositories() {
        repositories = new ArrayList<>();

        Call<List<Repo>> call = githubApi.obtenerRepositorios(APIGit.obtenerNombreUsuarioCliente());
        call.enqueue(new Callback<List<Repo>>() {
            /**
             * @param call
             * @param response
             */
            @Override
            public void onResponse(Call<List<Repo>> call, Response<List<Repo>> response) {
                if (response.isSuccessful()) {
                    repositories = response.body();
                    displayList();
                } else {
                    displayMessage("Error en la respuesta del servidor");
                    int statusCode = response.code();
                    String message = response.message();
                    Log.e(TAG, "Error al obtener los repositorios");
                }
            }
            /**
             * @param call
             * @param t
             */
            @Override
            public void onFailure(Call<List<Repo>> call, Throwable t) {
                displayMessage("Error de conexión");
            }
        });
    }

    private void displayList() {
        repositoryAdapter = new RepoAdapter(repositories, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(repositoryAdapter);
        repositoryAdapter.setOnDeleteClickListener(this);
        repositoryAdapter.setOnEditClickListener(this);
    }


    private void openRepositoryForm() {
        Intent intent = new Intent(this, RepoForm.class);
        startActivity(intent);
    }

    /**
     * @param position
     */
    @Override
    public void onDeleteClick(int position) {
        showDeleteConfirmationDialog(position);
    }

    /**
     * @param position
     */
    @Override
    public void onEditClick(int position) {
        Repo repositoryToEdit = repositories.get(position);
        openEditRepositoryForm(repositoryToEdit);
    }

    /**
     * @param position
     */
    private void showDeleteConfirmationDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Eliminar Repositorio");
        builder.setMessage("¿Seguro deseas eliminar este repositorio?");
        builder.setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteRepository(position);
            }
        });
        builder.setNegativeButton("Cancelar", null);

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    /**
     * @param position
     */
    private void deleteRepository(final int position) {
        Repo repositoryToDelete = repositories.get(position);
        String token = "Bearer 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";
        String owner = "Dbalsec";
        String repo = repositoryToDelete.getName();

        Call<Void> call = githubApi.eliminarRepositorio(token,owner, repo);
        Log.d(TAG, "Deleting repository - Owner: " + owner + ", Repo: " + repo);


        call.enqueue(new Callback<Void>() {
            /**
             * Si la respuesta es exitosa, elimina localmente el repositorio de la lista, notifica al adaptador sobre
             * el cambio y muestra un mensaje indicando que el repositorio se eliminó exitosamente.
             * @param call
             * @param response
             */
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    // Eliminar localmente el repositorio de la lista
                    repositories.remove(position);
                    repositoryAdapter.notifyItemRemoved(position);
                    displayMessage("Repositorio eliminado exitosamente");
                } else {
                    displayMessage("Error al eliminar el repositorio");
                    // Manejar el error de eliminación
                    // Log detalles adicionales
                    Log.e(TAG, "Error al eliminar el repositorio. Código de error: " + response.code());
                }
            }
            /**
             * Manejar cualquier error de conexión que pueda ocurrir durante la llamada.
             * @param call
             * @param t
             */
            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                displayMessage("Error de conexión al eliminar el repositorio");
            }
        });
    }

    /**
     * Facilita la transición a la actividad RepositoryForm en modo de edición, llevando consigo los detalles del repositorio
     * que se va a editar. Esto permite que el formulario se abra con los campos prellenados con la información del repositorio actual
     * @param repositoryToEdit el repositorio que se quiere editar
     */
    private void openEditRepositoryForm(Repo repositoryToEdit) {
        Intent intent = new Intent(this, RepoForm.class);
        intent.putExtra("EDIT_MODE", true);
        intent.putExtra("REPOSITORY_NAME", repositoryToEdit.getName());
        intent.putExtra("REPOSITORY_DESCRIPTION", repositoryToEdit.getDescription());
        startActivity(intent);
    }

    /**
     * Desplegar mensaje en Toast
     * @param msg
     */
    private void displayMessage(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}