package com.example.gitrepo;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import modelos.Repo;
public class RepoItem extends Fragment{
    private TextView repoName, repoDescription, repoCreationDate;
    private Repo repository;


    /**
     *
     * @param inflater
     * @param container
     *
     * @param savedInstanceState
     *
     * @return
     */
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.repoitem, container, false);

        repoName = view.findViewById(R.id.repoName);
        repoDescription = view.findViewById(R.id.repoDescription);
        repoCreationDate = view.findViewById(R.id.repoCreationDate);

        repoName.setText(repository.getName());
        repoDescription.setText(repository.getDescription());
        repoCreationDate.setText(repository.getCreationDate());

        return view;
    }

}