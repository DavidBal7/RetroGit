package modelos;

import com.google.gson.annotations.SerializedName;

public class Repo {
    @SerializedName("name")
    private String name;
    @SerializedName("description")
    private String description;
    @SerializedName("created_at")
    private String creationDate;


    /**
     *
     * @param name
     * @param description
     * @param creationDate
     */
    public Repo(String name, String description, String creationDate) {
        this.name = name;
        this.description = description;
        this.creationDate = creationDate;
    }



    public String getName() {
        return name;
    }


    public String getDescription() {
        return description;
    }


    public String getCreationDate() {

        return creationDate;
    }

    public void setName(String name) {

        this.name = name;
    }


    public void setDescription(String description) {

        this.description = description;
    }

    public void setCreationDate(String creationDate) {

        this.creationDate = creationDate;
    }

}
